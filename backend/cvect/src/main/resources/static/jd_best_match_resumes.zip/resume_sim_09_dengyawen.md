工作经历
- 某数据智能与增长平台（S公司） | 前端技术专家 | 2020-06 至今
  - 负责增长实验平台与用户画像平台前端架构分析与设计，主导 Vue3 + TypeScript + Element-Plus 技术栈升级，推动组件化与模块化落地。
  - 深入理解 Web 标准与语义化：重构埋点配置与报表模块，做到表现/数据分离（domain + view model），代码复杂度下降 20%。
  - 工程化：自建 webpack5 构建与发布体系（多环境、代码分割、按需加载、权限扫描）；历史项目通过 gulp 维护静态资源与打包；构建稳定性故障降至 0。
  - 前端安全与测试：CSP、依赖漏洞扫描、XSS/CSRF；单测（Jest）+ E2E（Cypress）覆盖核心链路 80%+。
  - 深度参与用户研究：与研究团队做可用性测试与定性访谈，优化实验创建流程与提示体系；实验创建成功率提升 18%，产品 NPS 提升 9 分。

- 某大型电商平台（T公司） | 前端开发工程师 -> 高级前端工程师 | 2015-07 至 2020-05
  - 负责营销活动中台与移动端 H5 页面（Vant），熟练使用 HTML5 新特性构建移动端 WebApp；处理多端兼容与性能优化。
  - 在活动引擎中使用 OOP + 设计模式抽象活动规则（满减/拼团/抽奖），并接入 A/B 实验，活动转化提升 9%+。

教育背景
- 华南理工大学 | 学士 计算机科学与技术 | 2011 至 2015

技术栈
- HTML5/CSS3/JavaScript/TypeScript
- Vue3 / Vue Router / Pinia / Element-Plus / Vant
- Webpack5 / Vite / Gulp / ESLint / Prettier / Husky
- Sass/Less / PostCSS / 工程化与模块化 / 前后端分离
- 用户研究与可用性测试 / 埋点与 A/B 实验
- 测试（Jest, Cypress）/ 监控（Sentry）/ 安全（CSP, XSS/CSRF）

证书/荣誉
- 公司“用户体验专项”最佳实践奖
- 公开文章：前端可用性与转化提升（行业专栏）

个人信息
姓名：邓雅雯
目标岗位：前端技术专家 / 资深前端工程师
邮箱：yawen.deng@example.com
电话：+86 133-9055-4128
经验年限：11 年
方向：前端 + Vue3/用户体验/增长
简介：11年前端经验，精通 Vue3、Element-Plus、Vant，擅长前端架构设计与工程化治理，并长期实践用户研究与可用性优化；能以业务转化为目标推进技术方案落地，交付高质量、高效率代码。

项目经历
- 增长实验与分流平台（Experiment Platform）
  技术栈：Vue3, TypeScript, Element-Plus, Webpack5, Monaco Editor, Less, Jest, Cypress
  职责：主导实验创建流程、规则编辑器与分流配置；建设可用性测试与指标体系；落地权限与审计。
  成果：实验配置耗时从 30min 降至 12min；实验创建成功率提升 18%；线上误配置事故下降 70%。

- 用户画像与洞察报表（Insight Dashboard）
  技术栈：Vue3, ECharts, Web Worker, Canvas, Pinia, Sass, Sentry
  职责：负责大数据量渲染（虚拟滚动 + Worker 计算）；优化指标计算与导出性能；建设监控告警。
  成果：百万级数据渲染耗时下降 50%；报表交互帧率稳定 50fps+；导出耗时下降 45%。
